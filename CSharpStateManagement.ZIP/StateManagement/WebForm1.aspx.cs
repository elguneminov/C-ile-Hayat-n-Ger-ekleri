﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace StateManagement
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            Response.Write(Application["Company"] + "<br>");
            Response.Write(Application["Users"] + "<br>");
            
            if (Request.QueryString["Gonder"]!=null)
            {
                Response.Write(Request.QueryString["Gonder"]+"<br>");
            }
            if (Request.QueryString["Gonder1"] != null)
            {
                Response.Write(Request.QueryString["Gonder1"]);
            }
            if (!IsPostBack)
            {
                Session["Ourvalue"] = "C# Ogreniyorum";
                ViewState["Test"] = "Selcuk Celik";
                CustomControl1.Text = "Bu bir testdir";
                CustomControl1.Text2 = "Bu bir testdir 2222";
            }
            else
            {
                Response.Write("Degerimiz="+Session["Ourvalue"].ToString() + "<br>");
                if (ViewState["Test"] != null)
                    Response.Write(ViewState["Test"].ToString());
                else
                    Response.Write("View State TEst Yok");
            }
        }
    }
}