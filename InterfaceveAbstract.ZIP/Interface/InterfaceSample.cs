﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Interface
{

    interface IStore
    {
        void Read();
        void Write();
        Document getDoc();
    }

    interface ICompress
    {
        void Compress();
        void Decompress();
        Document getDoc();
    }

    public class Document : IStore, ICompress
    {
        #region IStore Explicit Implementation
        public string Str = "test"; 

        public void Read()
        {
            MessageBox.Show("Executing Document's Read Method for IStore");
            
        }

        public void Write()
        {
            MessageBox.Show("Executing Document's Write Method for IStore");
        }
        public Document getDoc()
        {
            return this;
        }
        #endregion // IStore

        #region ICompress Implicit Implementation

        public void Compress()
        {
            MessageBox.Show("Executing Document's Compress Method for ICompress");
        }
        public void Decompress()
        {
            MessageBox.Show("Executing Document's Decompress Method for ICompress");
        }
        #endregion // ICompress
    }
    public class InterfaceSample
    {
        IStore IObjStore = new Document();
        ICompress IObjCompress = new Document();
        
        public void getobj()
        {
            //Direkt Interface tip çevrimi üzerinden çağırmak. Sonuçta ınterface ler bir obje class ı gibi de kullanılır

            //IObjStore.Read();
            //IObjStore.Write();
            //IObjCompress.Compress();
            //IObjCompress.Decompress();

            // Esas olarak iş hayatında bu şekilde kullanımı çoktur. Interface üzerinden onun implemente edildiği class ın kendisinin 
            // çalışan bir instance ı yani o anki bellekteki objesini alıp istediğimizi yaparız !
            // Dependency Injection vb metodları anlatmıyorum her yerde bunlar zaten anlatılıyor.
            
            Document doc = IObjStore.getDoc();
            Document doc1 = IObjCompress.getDoc();
            
            MessageBox.Show(doc.Str);

        }
    }
}
