﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpTransaction
{
    public class Globals : System.ComponentModel.Component
    {
        private string _DBName;
        private string _LogoURL;
        public string _WebSiteHeader;
        public enum SQLType
        {
            MSSQL = 0,
            Oracle = 1,
            OleDB = 2,
            SyBase = 3
        }
        public enum ISOLEVEL
        {
            Read_Uncommitted = 1,
            Read_Committed = 2
        }
        public static SQLType SQL = SQLType.MSSQL;

        private static string mConnectionString = "";


        
        public System.Data.SqlClient.SqlConnection cnSQL;
        public Oracle.ManagedDataAccess.Client.OracleConnection cnOrSQL;




        public static string ConnectionString
        {
            get
            {
                // TODO Change application to read connection string from registry, rather then hardcode it as above.
                return mConnectionString;
            }
            set
            {
                mConnectionString = value;
                
            }
        } // ConnectionString
        [Browsable(true)]
        [Category("User Defined")]
        [Description("to change DB Name")]
        public string DBName
        {
            get
            {
                return _DBName;
            }
            set
            {
                _DBName = value;
            }
        }
        [Browsable(true)]
        [Category("User Defined")]
        [Description("Web Site Company Logo URL")]
        public string LogoURL
        {
            get
            {
                return _LogoURL;
            }
            set
            {
                _LogoURL = value;
            }
        }
        [Browsable(true)]
        [Category("User Defined")]
        [Description("Web Site Header")]
        public string WebSiteHeader
        {
            get
            {
                return _WebSiteHeader;
            }
            set
            {
                _WebSiteHeader = value;
            }
        }

        public static string ReadFromConfig(string ConnString)
        {
            string ConfigValue = ConfigurationManager.AppSettings[ConnString];
            return ConfigValue;
        }

        private SqlTransaction _Transaction = null;
        private Oracle.ManagedDataAccess.Client.OracleTransaction _OracleTransaction = null/* TODO Change to default(_) if this is not a reference type */;
        private System.Data.OleDb.OleDbTransaction _OleDBTransaction = null/* TODO Change to default(_) if this is not a reference type */;

        // **************************************************************************
        // *  
        // * Name:        Transaction
        // *
        // * Description: Used for transaction support.
        // *
        // * Parameters:  If this property is set, all database operations will be
        // *              performed in the context of a database transaction.
        // *
        // **************************************************************************

        public SqlTransaction Transaction
        {
            get
            {
                return _Transaction;
            }
            set
            {
                _Transaction = value;
            }
        } // Transaction
        public Oracle.ManagedDataAccess.Client.OracleTransaction OracleTransaction
        {
            get
            {
                return _OracleTransaction;
            }
            set
            {
                _OracleTransaction = value;
            }
        } // OracleTransaction
        public System.Data.OleDb.OleDbTransaction OLEDBTransaction
        {
            get
            {
                return _OleDBTransaction;
            }
            set
            {
                _OleDBTransaction = value;
            }
        } // OracleTransaction


        public bool BeginTransaction(IsolationLevel isolation_Level = IsolationLevel.ReadUncommitted)
        {
            try
            {
                if (SQL == SQLType.MSSQL)
                {
                    SqlConnection cn = new SqlConnection(ConnectionString);

                    cn.Open();
                    cnSQL = cn;


                    Transaction = cn.BeginTransaction(isolation_Level);

                    return true;
                }
                else if (SQL == SQLType.Oracle)
                {
                    Oracle.ManagedDataAccess.Client.OracleConnection cn = new Oracle.ManagedDataAccess.Client.OracleConnection(ConnectionString);
                    cn.Open();
                    cnOrSQL = cn;
                    OracleTransaction = cn.BeginTransaction(isolation_Level);
                    return true;
                }
                else if (SQL == SQLType.OleDB)
                {
                    System.Data.OleDb.OleDbConnection cn = new System.Data.OleDb.OleDbConnection(ConnectionString);
                    cn.Open();
                    OLEDBTransaction = cn.BeginTransaction();
                    return true;
                }
            }

            catch (Exception ex)
            {
                return false;
            }
            return false;
        } // BeginTransaction


        // **************************************************************************
        // *  
        // * Name:        CommitTransaction
        // *
        // * Description: Commit transaction to database.
        // *
        // * Returns:     Boolean indicating if operation was sucessful or not.
        // *
        // * Remarks:     Closes the transaction and sets it to Nothing so that all
        // *              subsequent database operations are performed outside a 
        // *              transaction.
        // *
        // **************************************************************************
        public bool CommitTransaction()
        {
            try
            {
                if (SQL == SQLType.MSSQL)
                {
                    if (Transaction == null)
                        throw new Exception("Programming error. Cannot commit transaction because the Sql Server Transaction object is nothing.");
                    Transaction.Commit();
                    Transaction = null;
                    cnSQL.Close();
                    this.Dispose();
                    return true;
                }
                else if (SQL == SQLType.Oracle)
                {
                    if (OracleTransaction == null)
                        throw new Exception("Programming error. Cannot commit transaction because the Oracle Transaction object is nothing.");
                    OracleTransaction.Commit();
                    OracleTransaction = null/* TODO Change to default(_) if this is not a reference type */;
                    cnOrSQL.Close();
                    this.Dispose();
                    return true;
                }
                else if (SQL == SQLType.OleDB)
                {
                    if (OLEDBTransaction == null)
                        throw new Exception("Programming error. Cannot commit transaction because the OleDB Transaction object is nothing.");
                    OLEDBTransaction.Commit();
                    OLEDBTransaction = null/* TODO Change to default(_) if this is not a reference type */;
                    this.Dispose();
                    return true;
                }
            }

            catch (Exception ex)
            {
                return false;
            }
            return false;
        }


        public bool RollbackTransaction()
        {
            try
            {
                if (SQL == SQLType.MSSQL)
                {
                    if (Transaction == null)
                        throw new Exception("Programming error. Cannot commit transaction because the SQL Server Transaction object is nothing.");
                    Transaction.Rollback();
                    Transaction = null;
                    cnSQL.Close();
                    this.Dispose();
                    return true;
                }
                else if (SQL == SQLType.Oracle)
                {
                    if (OracleTransaction == null)
                        throw new Exception("Programming error. Cannot commit transaction because the Oracle Transaction object is nothing.");
                    OracleTransaction.Rollback();
                    OracleTransaction = null/* TODO Change to default(_) if this is not a reference type */;
                    cnOrSQL.Close();
                    this.Dispose();
                    return true;
                }
                else if (SQL == SQLType.OleDB)
                {
                    if (OLEDBTransaction == null)
                        throw new Exception("Programming error. Cannot commit transaction because the OLEDB Transaction object is nothing.");
                    OLEDBTransaction.Rollback();
                    OLEDBTransaction = null/* TODO Change to default(_) if this is not a reference type */;
                    this.Dispose();
                    return true;
                }
            }

            catch (Exception ex)
            {
                // ExceptionManager.Publish(ex)
                return false;
            }
            return false;
        } // RollbackTransaction



        public Globals() : base()
        {

            // This call is required by the Windows Form Designer.
            InitializeComponent();
        }

        // UserControl overrides dispose to clean up the component list.
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (!(components == null))
                    components.Dispose();
            }
            base.Dispose(disposing);
        }

        // Required by the Windows Form Designer
        private System.ComponentModel.IContainer components;

        // NOTE: The following procedure is required by the Windows Form Designer
        // It can be modified using the Windows Form Designer.  
        // Do not modify it using the code editor.
        [System.Diagnostics.DebuggerStepThrough()]
        private void InitializeComponent()
        {
        }
    }
}
