﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharpTransaction
{
    public partial class Form1 : Form
    {
        public string SqlType = "";
        public Globals globals = new Globals();
           
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //string constr = ConfigurationManager.AppSettings["ConnStr"];
            //string sql = "INSERT INTO LIVE (UID,USERNAME,COUNTRY,CITY) VALUES ('8888888','SELCUK CELIK','Turkiye','Istanbul')";
            //string sql1 = "INSERT INTO LIVEX (UID,USERNAME,COUNTRY,CITY) VALUES ('5555','SPYTRON','Turkiye','Istanbul')";
            //SqlConnection cn = new SqlConnection(constr);
            //SqlCommand  command = new SqlCommand(sql);
            //try
            //{
            //    cn.Open();
            //    command.Connection = cn;
            //    command.Transaction = cn.BeginTransaction(IsolationLevel.ReadUncommitted);
            //    command.ExecuteNonQuery();
            //    command.CommandText = sql1;
            //    command.ExecuteNonQuery();
            //    command.Transaction.Commit();
            //    cn.Close();
            //}
            //catch (Exception ex)
            //{
            //    command.Transaction.Rollback();
            //    cn.Close();
            //}
            SqlType = Globals.ReadFromConfig("SqlType");
            Globals.SQL = SqlType == "MSSQL" ? Globals.SQLType.MSSQL : SqlType == "ORACLE" ? Globals.SQLType.Oracle : Globals.SQLType.OleDB;
            Globals.ConnectionString = Globals.ReadFromConfig("ConnStr");
            string sql = "INSERT INTO LIVE (UID,USERNAME,COUNTRY,CITY) VALUES ('8888888','SELCUK CELIK','Turkiye','Istanbul')";
            string sql1 = "INSERT INTO LIVEX (UID,USERNAME,COUNTRY,CITY) VALUES ('5555','SPYTRON','Turkiye','Istanbul')";
            globals.BeginTransaction(IsolationLevel.ReadUncommitted);
            SqlCommand command = new SqlCommand(sql);
            
            try
            {
                command.Transaction = globals.Transaction;
                command.Connection = globals.cnSQL;
                
                command.ExecuteNonQuery();
                command.CommandText = sql1;
                command.ExecuteNonQuery();
                globals.CommitTransaction();
                
            }
            catch (Exception ex)
            {
                globals.RollbackTransaction();
                
            }

        }
    }
}
